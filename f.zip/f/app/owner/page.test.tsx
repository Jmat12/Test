import { render, screen, waitFor } from "@testing-library/react";
import OwnerHome from "./page";
import { apiMe, apiOwnerCitas } from "../../lib/services/api";

// Mock the API functions
jest.mock("../../lib/services/api");

const mockOwner = { nombres: "Juan", apellidos: "Perez" };
const now = Date.now();
const mockCitas = [
  {
    id: 1,
    fecha: new Date(now + 1000 * 60 * 60).toISOString(),
    motivo: "Chequeo",
    estado: "Pendiente",
  }, // future
  {
    id: 2,
    fecha: new Date(now - 1000 * 60 * 60).toISOString(),
    motivo: "Vacuna",
    estado: "Completada",
  }, // past
];

describe("OwnerHome component", () => {
  beforeEach(() => {
    jest.clearAllMocks();
  });

  test("shows loading initially", () => {
    render(<OwnerHome />);
    expect(screen.getByText("Cargando...")).toBeInTheDocument();
  });

  test("renders owner name and upcoming citas", async () => {
    (apiMe as jest.Mock).mockResolvedValue({ dueno: mockOwner });
    (apiOwnerCitas as jest.Mock).mockResolvedValue(mockCitas);

    render(<OwnerHome />);

    await waitFor(() => {
      // Owner name
      expect(screen.getByText(/Hola Juan/i)).toBeInTheDocument();

      // Upcoming citas (future only)
      expect(screen.getByText(/Chequeo/)).toBeInTheDocument();
      expect(screen.queryByText(/Vacuna/)).not.toBeInTheDocument();

      // Links
      expect(screen.getByText("Mascotas")).toBeInTheDocument();
      expect(screen.getByText("Citas")).toBeInTheDocument();
    });
  });

  test("shows error message if API fails", async () => {
    (apiMe as jest.Mock).mockRejectedValue(new Error("fail"));
    (apiOwnerCitas as jest.Mock).mockRejectedValue(new Error("fail"));

    render(<OwnerHome />);

    await waitFor(() =>
      expect(
        screen.getByText(/No se pudo cargar tu panel/i)
      ).toBeInTheDocument()
    );
  });

  test("shows fallback text if owner name missing", async () => {
    (apiMe as jest.Mock).mockResolvedValue({ dueno: {} });
    (apiOwnerCitas as jest.Mock).mockResolvedValue([]);

    render(<OwnerHome />);

    await waitFor(() =>
      expect(screen.getByText(/Hola dueno/i)).toBeInTheDocument()
    );
  });

  test("displays message if no upcoming citas", async () => {
    (apiMe as jest.Mock).mockResolvedValue({ dueno: mockOwner });
    (apiOwnerCitas as jest.Mock).mockResolvedValue([]); // no citas

    render(<OwnerHome />);

    await waitFor(() =>
      expect(
        screen.getByText(/Aun no tienes citas registradas/i)
      ).toBeInTheDocument()
    );
  });
});

module.exports = [
"[externals]/next/dist/compiled/next-server/app-page-turbo.runtime.dev.js [external] (next/dist/compiled/next-server/app-page-turbo.runtime.dev.js, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("next/dist/compiled/next-server/app-page-turbo.runtime.dev.js", () => require("next/dist/compiled/next-server/app-page-turbo.runtime.dev.js"));

module.exports = mod;
}),
"[externals]/util [external] (util, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("util", () => require("util"));

module.exports = mod;
}),
"[externals]/stream [external] (stream, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("stream", () => require("stream"));

module.exports = mod;
}),
"[externals]/path [external] (path, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("path", () => require("path"));

module.exports = mod;
}),
"[externals]/http [external] (http, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("http", () => require("http"));

module.exports = mod;
}),
"[externals]/https [external] (https, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("https", () => require("https"));

module.exports = mod;
}),
"[externals]/url [external] (url, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("url", () => require("url"));

module.exports = mod;
}),
"[externals]/fs [external] (fs, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("fs", () => require("fs"));

module.exports = mod;
}),
"[externals]/crypto [external] (crypto, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("crypto", () => require("crypto"));

module.exports = mod;
}),
"[externals]/http2 [external] (http2, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("http2", () => require("http2"));

module.exports = mod;
}),
"[externals]/assert [external] (assert, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("assert", () => require("assert"));

module.exports = mod;
}),
"[externals]/tty [external] (tty, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("tty", () => require("tty"));

module.exports = mod;
}),
"[externals]/os [external] (os, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("os", () => require("os"));

module.exports = mod;
}),
"[externals]/zlib [external] (zlib, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("zlib", () => require("zlib"));

module.exports = mod;
}),
"[externals]/events [external] (events, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("events", () => require("events"));

module.exports = mod;
}),
"[project]/lib/services/api.ts [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "api",
    ()=>api,
    "apiApproveVet",
    ()=>apiApproveVet,
    "apiAtenderCita",
    ()=>apiAtenderCita,
    "apiCancelarCita",
    ()=>apiCancelarCita,
    "apiCrearCita",
    ()=>apiCrearCita,
    "apiCreateCentro",
    ()=>apiCreateCentro,
    "apiCreatePet",
    ()=>apiCreatePet,
    "apiDeletePet",
    ()=>apiDeletePet,
    "apiDisponibilidad",
    ()=>apiDisponibilidad,
    "apiHistorial",
    ()=>apiHistorial,
    "apiListCentros",
    ()=>apiListCentros,
    "apiListNotifications",
    ()=>apiListNotifications,
    "apiListPendingVets",
    ()=>apiListPendingVets,
    "apiListPets",
    ()=>apiListPets,
    "apiListVetsActivos",
    ()=>apiListVetsActivos,
    "apiLogin",
    ()=>apiLogin,
    "apiMe",
    ()=>apiMe,
    "apiOwnerCitas",
    ()=>apiOwnerCitas,
    "apiProgramarAgenda",
    ()=>apiProgramarAgenda,
    "apiRegisterOwner",
    ()=>apiRegisterOwner,
    "apiRegisterVet",
    ()=>apiRegisterVet,
    "apiRejectVet",
    ()=>apiRejectVet,
    "apiRequestReset",
    ()=>apiRequestReset,
    "apiResetPassword",
    ()=>apiResetPassword,
    "apiUpdateMe",
    ()=>apiUpdateMe,
    "apiUpdatePet",
    ()=>apiUpdatePet,
    "apiVetCitas",
    ()=>apiVetCitas,
    "apiVetUpdateCentro",
    ()=>apiVetUpdateCentro,
    "isAxiosError",
    ()=>isAxiosError,
    "setAuthToken",
    ()=>setAuthToken
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$axios$2f$lib$2f$axios$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/axios/lib/axios.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$axios$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/node_modules/axios/index.js [app-ssr] (ecmascript) <locals>");
"use client";
;
const baseURL = process.env.NEXT_PUBLIC_API_URL || "http://localhost:4000";
const api = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$axios$2f$lib$2f$axios$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"].create({
    baseURL
});
function setAuthToken(token) {
    if (token) api.defaults.headers.common.Authorization = `Bearer ${token}`;
    else delete api.defaults.headers.common.Authorization;
}
function isAxiosError(error) {
    return error instanceof __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$axios$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$locals$3e$__["AxiosError"];
}
async function apiLogin(correo, contrasena) {
    const { data } = await api.post("/auth/login", {
        correo,
        contrasena
    });
    return data;
}
async function apiRegisterOwner(input) {
    const { data } = await api.post("/auth/register/owner", input);
    return data;
}
async function apiRegisterVet(input) {
    const { data } = await api.post("/auth/register/vet", input);
    return data;
}
async function apiMe() {
    const { data } = await api.get("/me");
    return data;
}
async function apiUpdateMe(patch) {
    const { data } = await api.put("/me", patch);
    return data;
}
async function apiRequestReset(correo) {
    const { data } = await api.post("/auth/request-password-reset", {
        correo
    });
    return data;
}
async function apiResetPassword(token, contrasena) {
    const { data } = await api.post("/auth/reset-password", {
        token,
        contrasena
    });
    return data;
}
async function apiListCentros() {
    const { data } = await api.get("/centros");
    return data;
}
async function apiCreateCentro(payload) {
    const { data } = await api.post("/centros", payload);
    return data;
}
async function apiListVetsActivos(params) {
    const { data } = await api.get("/veterinarios/activos", {
        params
    });
    return data;
}
async function apiDisponibilidad(veterinarioId, centroId) {
    const { data } = await api.get("/citas/disponibilidad", {
        params: {
            veterinarioId,
            centroId
        }
    });
    return data;
}
async function apiListPets() {
    const { data } = await api.get("/mascotas");
    return data;
}
async function apiCreatePet(pet) {
    const { data } = await api.post("/mascotas", pet);
    return data;
}
async function apiUpdatePet(id, patch) {
    const { data } = await api.put(`/mascotas/${id}`, patch);
    return data;
}
async function apiDeletePet(id) {
    const { data } = await api.delete(`/mascotas/${id}`);
    return data;
}
async function apiOwnerCitas() {
    const { data } = await api.get("/citas/owner");
    return data;
}
async function apiVetCitas() {
    const { data } = await api.get("/citas/vet");
    return data;
}
async function apiCrearCita(payload) {
    const { data } = await api.post("/citas", payload);
    return data;
}
async function apiCancelarCita(id, motivo) {
    const { data } = await api.patch(`/citas/${id}/cancel`, {
        motivo
    });
    return data;
}
async function apiAtenderCita(id, body) {
    const { data } = await api.patch(`/citas/${id}/atender`, body);
    return data;
}
async function apiHistorial(mascotaId) {
    const { data } = await api.get(`/historial/${mascotaId}`);
    return data;
}
async function apiProgramarAgenda(payload) {
    const { data } = await api.post("/vet/programaciones", payload);
    return data;
}
async function apiVetUpdateCentro(payload) {
    const { data } = await api.patch("/vet/centro", payload);
    return data;
}
async function apiListPendingVets() {
    const { data } = await api.get("/admin/pending-vets");
    return data;
}
async function apiApproveVet(vetId, payload) {
    const { data } = await api.post(`/admin/vets/${vetId}/approve`, payload);
    return data;
}
async function apiRejectVet(vetId, motivo) {
    const { data } = await api.post(`/admin/vets/${vetId}/reject`, {
        motivo
    });
    return data;
}
async function apiListNotifications() {
    const { data } = await api.get("/notificaciones");
    return data;
}
}),
"[project]/lib/auth/session.tsx [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "SessionProvider",
    ()=>SessionProvider,
    "useSession",
    ()=>useSession
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/server/route-modules/app-page/vendored/ssr/react-jsx-dev-runtime.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/server/route-modules/app-page/vendored/ssr/react.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$services$2f$api$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/lib/services/api.ts [app-ssr] (ecmascript)");
"use client";
;
;
;
const CTX = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["createContext"])(undefined);
const SKEY = "vetchain_session";
function SessionProvider({ children }) {
    const [cuenta, setCuenta] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])(null);
    const [loading, setLoading] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])(true);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useEffect"])(()=>{
        try {
            const raw = window.localStorage.getItem(SKEY);
            if (raw) {
                const { token } = JSON.parse(raw);
                if (token) {
                    (0, __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$services$2f$api$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["setAuthToken"])(token);
                    (0, __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$services$2f$api$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["apiMe"])().then((me)=>setCuenta(mapCuenta(me))).catch(()=>{
                        (0, __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$services$2f$api$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["setAuthToken"])(null);
                        window.localStorage.removeItem(SKEY);
                        setCuenta(null);
                    }).finally(()=>setLoading(false));
                    return;
                }
            }
        } catch  {
        // ignore parse errors
        }
        setLoading(false);
    }, []);
    const login = async (correo, contrasena)=>{
        try {
            const data = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$services$2f$api$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["apiLogin"])(correo, contrasena);
            (0, __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$services$2f$api$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["setAuthToken"])(data.token);
            const me = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$services$2f$api$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["apiMe"])();
            const info = mapCuenta(me);
            setCuenta(info);
            window.localStorage.setItem(SKEY, JSON.stringify({
                token: data.token,
                cuenta: info
            }));
            return info;
        } catch (error) {
            (0, __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$services$2f$api$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["setAuthToken"])(null);
            window.localStorage.removeItem(SKEY);
            throw new Error(readableError(error));
        }
    };
    const logout = ()=>{
        setCuenta(null);
        (0, __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$services$2f$api$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["setAuthToken"])(null);
        window.localStorage.setItem(SKEY, JSON.stringify({
            token: null,
            cuenta: null
        }));
    };
    const signupOwner = async (args)=>{
        try {
            await (0, __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$services$2f$api$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["apiRegisterOwner"])(args);
        } catch (error) {
            throw new Error(readableError(error));
        }
    };
    const signupVet = async (args)=>{
        try {
            await (0, __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$services$2f$api$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["apiRegisterVet"])(args);
        } catch (error) {
            throw new Error(readableError(error));
        }
    };
    const value = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useMemo"])(()=>({
            cuenta,
            loading,
            login,
            logout,
            signupOwner,
            signupVet
        }), [
        cuenta,
        loading
    ]);
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(CTX.Provider, {
        value: value,
        children: children
    }, void 0, false, {
        fileName: "[project]/lib/auth/session.tsx",
        lineNumber: 91,
        columnNumber: 10
    }, this);
}
function useSession() {
    const ctx = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useContext"])(CTX);
    if (!ctx) throw new Error("useSession must be used within SessionProvider");
    return ctx;
}
function mapCuenta(me) {
    return {
        correo: me.cuenta.correo,
        rol: me.cuenta.rol
    };
}
function readableError(error) {
    if ((0, __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$services$2f$api$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["isAxiosError"])(error)) {
        return error.response?.data?.error ?? "Solicitud rechazada por el servidor.";
    }
    if (error instanceof Error) return error.message;
    return "Ocurrio un error inesperado. Intenta nuevamente.";
}
}),
"[externals]/next/dist/server/app-render/action-async-storage.external.js [external] (next/dist/server/app-render/action-async-storage.external.js, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("next/dist/server/app-render/action-async-storage.external.js", () => require("next/dist/server/app-render/action-async-storage.external.js"));

module.exports = mod;
}),
"[externals]/next/dist/server/app-render/work-unit-async-storage.external.js [external] (next/dist/server/app-render/work-unit-async-storage.external.js, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("next/dist/server/app-render/work-unit-async-storage.external.js", () => require("next/dist/server/app-render/work-unit-async-storage.external.js"));

module.exports = mod;
}),
"[externals]/next/dist/server/app-render/work-async-storage.external.js [external] (next/dist/server/app-render/work-async-storage.external.js, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("next/dist/server/app-render/work-async-storage.external.js", () => require("next/dist/server/app-render/work-async-storage.external.js"));

module.exports = mod;
}),
"[project]/src/assets/LOGO.png (static in ecmascript)", ((__turbopack_context__) => {

__turbopack_context__.v("/_next/static/media/LOGO.77f0441d.png");}),
"[project]/src/assets/LOGO.png.mjs { IMAGE => \"[project]/src/assets/LOGO.png (static in ecmascript)\" } [app-ssr] (structured image object with data url, ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>__TURBOPACK__default__export__
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$assets$2f$LOGO$2e$png__$28$static__in__ecmascript$29$__ = __turbopack_context__.i("[project]/src/assets/LOGO.png (static in ecmascript)");
;
const __TURBOPACK__default__export__ = {
    src: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$assets$2f$LOGO$2e$png__$28$static__in__ecmascript$29$__["default"],
    width: 1024,
    height: 541,
    blurWidth: 8,
    blurHeight: 4,
    blurDataURL: "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAECAYAAACzzX7wAAAAiElEQVR42hWKvQrCMBgA06T9PhNILMZgFpt2UbK4iT8UqYhQXbQYRTffw9EXb3rTcRxhADAp5ovclUuujeVybITKNWNpSgaE1tPvq/m39+vP7Zuu2hw+vj49lZnZJELimFXb9dvu6iCL0rvj+eJv4bHqQotSSTJMCaWMZoDRKUNEEGIEXGDsSQ8AuQ439loT2gAAAABJRU5ErkJggg=="
};
}),
"[project]/components/Header.tsx [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>Header
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/server/route-modules/app-page/vendored/ssr/react-jsx-dev-runtime.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$image$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/image.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$client$2f$app$2d$dir$2f$link$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/client/app-dir/link.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/navigation.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$auth$2f$session$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/lib/auth/session.tsx [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$assets$2f$LOGO$2e$png$2e$mjs__$7b$__IMAGE__$3d3e$__$225b$project$5d2f$src$2f$assets$2f$LOGO$2e$png__$28$static__in__ecmascript$2922$__$7d$__$5b$app$2d$ssr$5d$__$28$structured__image__object__with__data__url$2c$__ecmascript$29$__ = __turbopack_context__.i('[project]/src/assets/LOGO.png.mjs { IMAGE => "[project]/src/assets/LOGO.png (static in ecmascript)" } [app-ssr] (structured image object with data url, ecmascript)');
"use client";
;
;
;
;
;
;
function Header() {
    const { cuenta, logout } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$auth$2f$session$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useSession"])();
    const router = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useRouter"])();
    const pathname = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["usePathname"])();
    const mainLink = cuenta?.rol === "dueno" ? "/owner" : cuenta?.rol === "veterinario" ? "/vet" : cuenta?.rol === "admin" ? "/admin" : "/";
    const links = [
        {
            href: mainLink,
            label: "Inicio"
        },
        {
            href: "/profile",
            label: "Perfil"
        },
        {
            href: "/notificaciones",
            label: "Notificaciones"
        },
        ...cuenta?.rol === "dueno" ? [
            {
                href: "/owner/mascotas",
                label: "Mascotas"
            },
            {
                href: "/owner/citas",
                label: "Citas"
            },
            {
                href: "/owner/veterinarios",
                label: "Veterinarios"
            }
        ] : [],
        ...cuenta?.rol === "veterinario" ? [
            {
                href: "/vet/agenda",
                label: "Agenda"
            },
            {
                href: "/vet/citas",
                label: "Citas"
            },
            {
                href: "/vet/centro",
                label: "Centros"
            }
        ] : [],
        ...cuenta?.rol === "admin" ? [
            {
                href: "/admin/centros",
                label: "Centros"
            },
            {
                href: "/admin/cuentas",
                label: "Cuentas"
            }
        ] : []
    ];
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("header", {
        className: "sticky top-0 z-10 border-b bg-white/90 backdrop-blur",
        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: "mx-auto flex max-w-6xl items-center gap-4 px-4 py-3",
            children: [
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$client$2f$app$2d$dir$2f$link$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"], {
                    href: mainLink,
                    className: "flex items-center gap-3 font-semibold text-teal-700",
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                            className: "inline-flex h-9 w-9 items-center justify-center rounded-full border border-teal-100 bg-white shadow-sm",
                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$image$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"], {
                                src: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$assets$2f$LOGO$2e$png$2e$mjs__$7b$__IMAGE__$3d3e$__$225b$project$5d2f$src$2f$assets$2f$LOGO$2e$png__$28$static__in__ecmascript$2922$__$7d$__$5b$app$2d$ssr$5d$__$28$structured__image__object__with__data__url$2c$__ecmascript$29$__["default"],
                                alt: "VetChain",
                                className: "h-7 w-7 object-contain"
                            }, void 0, false, {
                                fileName: "[project]/components/Header.tsx",
                                lineNumber: 47,
                                columnNumber: 13
                            }, this)
                        }, void 0, false, {
                            fileName: "[project]/components/Header.tsx",
                            lineNumber: 46,
                            columnNumber: 11
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                            className: "tracking-tight",
                            children: "VetChain"
                        }, void 0, false, {
                            fileName: "[project]/components/Header.tsx",
                            lineNumber: 49,
                            columnNumber: 11
                        }, this)
                    ]
                }, void 0, true, {
                    fileName: "[project]/components/Header.tsx",
                    lineNumber: 45,
                    columnNumber: 9
                }, this),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("nav", {
                    className: "ml-6 flex items-center gap-4 text-sm",
                    children: links.map((link)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$client$2f$app$2d$dir$2f$link$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"], {
                            href: link.href,
                            className: `hover:text-teal-700 ${pathname === link.href ? "text-teal-700 font-medium" : "text-slate-700"}`,
                            children: link.label
                        }, link.href, false, {
                            fileName: "[project]/components/Header.tsx",
                            lineNumber: 53,
                            columnNumber: 13
                        }, this))
                }, void 0, false, {
                    fileName: "[project]/components/Header.tsx",
                    lineNumber: 51,
                    columnNumber: 9
                }, this),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "ml-auto flex items-center gap-3 text-sm",
                    children: cuenta ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["Fragment"], {
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                className: "text-slate-600",
                                children: [
                                    cuenta.correo,
                                    " - ",
                                    cuenta.rol
                                ]
                            }, void 0, true, {
                                fileName: "[project]/components/Header.tsx",
                                lineNumber: 65,
                                columnNumber: 15
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                className: "text-teal-700 hover:underline",
                                onClick: ()=>{
                                    logout();
                                    router.push("/");
                                },
                                children: "Cerrar sesion"
                            }, void 0, false, {
                                fileName: "[project]/components/Header.tsx",
                                lineNumber: 68,
                                columnNumber: 15
                            }, this)
                        ]
                    }, void 0, true) : /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$client$2f$app$2d$dir$2f$link$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"], {
                        href: "/",
                        className: "text-teal-700 hover:underline",
                        children: "Login"
                    }, void 0, false, {
                        fileName: "[project]/components/Header.tsx",
                        lineNumber: 79,
                        columnNumber: 13
                    }, this)
                }, void 0, false, {
                    fileName: "[project]/components/Header.tsx",
                    lineNumber: 62,
                    columnNumber: 9
                }, this)
            ]
        }, void 0, true, {
            fileName: "[project]/components/Header.tsx",
            lineNumber: 44,
            columnNumber: 7
        }, this)
    }, void 0, false, {
        fileName: "[project]/components/Header.tsx",
        lineNumber: 43,
        columnNumber: 5
    }, this);
}
}),
];

//# sourceMappingURL=%5Broot-of-the-server%5D__ac46bd97._.js.map